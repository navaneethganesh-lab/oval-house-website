import OVALHouseWebsite from "./components/OVALHouseWebsite";

export default function Home() {
  return <OVALHouseWebsite />;
}